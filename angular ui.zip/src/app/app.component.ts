﻿import { Component, OnInit } from '@angular/core';

import { AccountService } from './_services';
import { User } from './_models';

@Component({ selector: 'app', templateUrl: 'app.component.html' })
export class AppComponent implements OnInit{
    user: any;
    loggedinstatus =  false;

    constructor(private accountService: AccountService) {
        this.accountService.user.subscribe(x => {
            this.user = x

            if (this.user !== null && this.user !== undefined) {
                if (this.user.code != 200) {
                    this.user = null;
                }}
            }
            );
    }

    ngOnInit() {
        if (this.user !== null && this.loggedinstatus == true) {
            this.accountService.user.subscribe(x => this.user = x);
    
        } else {
            this.user = null;
        }
            // this.accountService.user.subscribe(x => this.user = x);
            this.accountService.user.subscribe(x => {
                this.user = x
    
                if (this.user !== null && this.user !== undefined) {
                    if (this.user.code != 200) {
                        this.user = null;
                    }}
                }
                );
        }
    

    logout() {
        this.accountService.logout();
    }

    refresh() {
        // console.log(this.loggedinstatus, this.user)

        // user.addEventListener('loadend', function(e) {
        //     console.log('Image load finished');
        //   });
    }

}