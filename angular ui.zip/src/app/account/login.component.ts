﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { AccountService, AlertService } from '@app/_services';
import { error } from '@angular/compiler/src/util';
import { AppComponent } from '@app/app.component';

@Component({ templateUrl: 'login.component.html' })
export class LoginComponent implements OnInit {
    form: FormGroup;
    loading = false;
    submitted = false;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private accountService: AccountService,
        private alertService: AlertService,
        private appComponent: AppComponent
    ) { }

    ngOnInit() {
        this.form = this.formBuilder.group({
            username: ['', Validators.required],
            password: ['', Validators.required]
        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

    onSubmit() {
        this.submitted = true;

        // reset alerts on submit
        this.alertService.clear();

        // stop here if form is invalid
        if (this.form.invalid) {
            return;
        }

        this.loading = true;
        // this.accountService.login(this.f.username.value, this.f.password.value)
        //     .pipe(first())
        //     .subscribe({
        //         next: () => {
        //             // get return url from query parameters or default to home page
        //             const returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
        //             this.router.navigateByUrl(returnUrl);
        //         },
        //         error: error => {
        //             this.alertService.error(error);
        //             this.loading = false;
        //         }
        //     });



            this.accountService.login(this.f.username.value, this.f.password.value)
            .pipe()
            .subscribe( (data: any) => {
                if (data.code == 200) {
                    this.appComponent.loggedinstatus = true;
                    this.appComponent.user = data.user;

                    this.appComponent.refresh();
                    this.alertService.success('Logged In');
                    this.router.navigateByUrl('home');
                } else {
                    this.appComponent.loggedinstatus = false;
                    this.alertService.error('Incorrect credentials');
                    this.loading = false;
                    console.log('error');

                    // const returnUrl = this.route.snapshot.queryParams['/'] || '/';
                    // this.router.navigateByUrl(returnUrl);
                }
            },
                (error: any) => {
                    this.alertService.error(error);
                    this.loading = false;
                    console.log(error);
                });
             
    }
}