﻿import { Component } from '@angular/core';

import { User } from '@app/_models';
import { AccountService } from '@app/_services';

@Component({ templateUrl: 'home.component.html' })
export class HomeComponent {
    user: User;
    userclone: any;

    constructor(private accountService: AccountService) {
        this.user = this.accountService.userValue;
        this.userclone = localStorage.getItem('user');
        if (this.userclone != null  && this.userclone != undefined) {
            if (this.user != null  && this.user != undefined) {
                this.userclone = localStorage.getItem('user');
                this.userclone = JSON.parse(localStorage.getItem('user'))
            } else {
                this.userclone.user = 'Anonomyous'
            }
        } else {
            this.userclone.user = 'Anonomyous'
        }

    }
}