﻿export class User {
    id: Number;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    name: string;
    token: string;
}