import { Component, OnInit } from '@angular/core';
import { AccountService } from '@app/_services';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.less']
})
export class CardComponent implements OnInit {


  cardnumber: any;
  responsecard: any;
  cardlength: any;

  cardres:any;
  gogo:any;

  form: FormGroup;
    loading = false;
    submitted = false;

  constructor(private accountService: AccountService,
    private formBuilder: FormBuilder,
    ) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      cardnumber: ['', Validators.required],
      password: ['', Validators.required]
  });

  }
  logout() {
    this.accountService.logout();
}

numberof(e) {
  e = e.toString();
   this.cardlength = e.length;
}

getInputValue() {


  fetch('http://localhost:3000/mask_card?card_no='+this.cardnumber)
      .then(response => response.json())
      .then(data =>{
        this.responsecard = data
      } )

}
}
